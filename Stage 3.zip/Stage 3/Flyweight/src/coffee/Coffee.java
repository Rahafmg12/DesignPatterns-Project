

package coffee;


import java.util.HashMap;
import java.util.Map;



public interface Coffee {
    void serveCoffee(CoffeeContext context);
}

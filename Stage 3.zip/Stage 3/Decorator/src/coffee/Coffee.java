
package coffee;


interface Coffee {
    String getDescription();
    double getCost();
}

